const els = {
  total: document.querySelector("#metricTotal"),
  hot: document.querySelector("#metricHot"),
  answered: document.querySelector("#metricAnswered"),
  fallback: document.querySelector("#metricFallback"),
  table: document.querySelector("#leadTable"),
  formLead: document.querySelector("#formLead"),
  callLead: document.querySelector("#callLead"),
  refresh: document.querySelector("#refreshLeads"),
  startVoice: document.querySelector("#startVoice"),
  testMic: document.querySelector("#testMic"),
  talkVoice: document.querySelector("#talkVoice"),
  stopVoice: document.querySelector("#stopVoice"),
  typedTurn: document.querySelector("#typedTurn"),
  voiceStatus: document.querySelector("#voiceStatus"),
  transcriptBox: document.querySelector("#transcriptBox"),
  serverWarning: document.querySelector("#serverWarning"),
};

let voiceRecognition;
let voiceLead = {};
let voiceActive = false;
let voiceListening = false;
let voiceConversation = [];

if (window.location.protocol === "file:") {
  els.serverWarning.hidden = false;
  els.voiceStatus.textContent = "Open the server URL above. Voice AI cannot work from file://.";
}

async function api(path, options = {}) {
  if (window.location.protocol === "file:") {
    throw new Error("Open http://127.0.0.1:4173/app.html. The API cannot run from file://.");
  }

  const response = await fetch(path, {
    headers: { "content-type": "application/json" },
    ...options,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: "Request failed" }));
    throw new Error(error.error || "Request failed");
  }

  return response.json();
}

function formToPayload(form) {
  const data = new FormData(form);
  return Object.fromEntries(
    Array.from(data.entries()).map(([key, value]) => [key, value === "on" ? true : value]),
  );
}

function statusClass(status) {
  return status.toLowerCase();
}

function renderMetrics(metrics) {
  els.total.textContent = metrics.total;
  els.hot.textContent = metrics.hot;
  els.answered.textContent = metrics.answered;
  els.fallback.textContent = metrics.fallbackSent;
}

function renderLeads(leads) {
  if (!leads.length) {
    els.table.innerHTML = '<p class="empty">No leads yet. Process a form lead or inbound call.</p>';
    return;
  }

  els.table.innerHTML = leads
    .map(
      (lead) => `
        <article class="lead-row">
          <div>
            <h3>${escapeHtml(lead.name)}</h3>
            <p>${escapeHtml(lead.project)} - ${escapeHtml(lead.interest)}</p>
            <small>${escapeHtml(lead.channel)} | ${new Date(lead.createdAt).toLocaleString()}</small>
          </div>
          <div>
            <p><strong>Budget:</strong> ${escapeHtml(lead.budget)}</p>
            <p><strong>Timeline:</strong> ${escapeHtml(lead.timeline)}</p>
            <p><strong>Finance:</strong> ${escapeHtml(lead.finance)}</p>
          </div>
          <div>
            <p>${escapeHtml(lead.summary)}</p>
            <small>${escapeHtml(lead.ownerNextStep)}</small>
          </div>
          <div>
            <span class="status ${statusClass(lead.status)}">${lead.status} ${lead.score}</span>
          </div>
        </article>
      `,
    )
    .join("");
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

async function refresh() {
  try {
    const [metrics, leads] = await Promise.all([api("/api/metrics"), api("/api/leads")]);
    renderMetrics(metrics);
    renderLeads(leads);
  } catch (error) {
    els.table.innerHTML = `<p class="empty">${escapeHtml(error.message)}</p>`;
  }
}

async function handleSubmit(event, endpoint) {
  event.preventDefault();
  const button = event.currentTarget.querySelector("button[type='submit']");
  button.disabled = true;
  button.textContent = endpoint.includes("inbound") ? "Answering..." : "Processing...";

  try {
    await api(endpoint, {
      method: "POST",
      body: JSON.stringify(formToPayload(event.currentTarget)),
    });
    await refresh();
  } finally {
    button.disabled = false;
    button.textContent = endpoint.includes("inbound") ? "Answer inbound call" : "Process form lead";
  }
}

els.formLead.addEventListener("submit", (event) => handleSubmit(event, "/api/leads"));
els.callLead.addEventListener("submit", (event) => handleSubmit(event, "/api/inbound-call"));
els.refresh.addEventListener("click", refresh);
els.startVoice.addEventListener("click", startVoiceDemo);
els.testMic.addEventListener("click", testMicrophone);
els.talkVoice.addEventListener("click", listenForTurn);
els.stopVoice.addEventListener("click", stopVoiceDemo);
els.typedTurn.addEventListener("submit", handleTypedTurn);

refresh();

function getSpeechRecognition() {
  return window.SpeechRecognition || window.webkitSpeechRecognition;
}

function speak(text) {
  return new Promise((resolve) => {
    if (!window.speechSynthesis) {
      resolve();
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.96;
    utterance.pitch = 1;
    utterance.onend = resolve;
    utterance.onerror = resolve;
    window.speechSynthesis.speak(utterance);
  });
}

async function startVoiceDemo() {
  if (window.location.protocol === "file:") {
    els.voiceStatus.textContent = "Open http://127.0.0.1:4173/app.html first. Gemini voice needs the local server.";
    return;
  }

  const Recognition = getSpeechRecognition();

  if (!Recognition) {
    els.voiceStatus.textContent =
      "This browser does not support free speech recognition. Use Chrome/Edge or the manual forms below.";
    return;
  }

  voiceLead = {
    name: "",
    interest: "",
    budget: "",
    timeline: "",
    finance: "",
    phone: "Browser voice demo",
    email: "voice-demo@example.com",
    project: "Parramatta Central",
    channel: "Browser voice demo",
    consent: true,
  };
  voiceActive = true;
  voiceConversation = [];
  els.transcriptBox.textContent = "";
  els.startVoice.disabled = true;
  els.talkVoice.disabled = false;
  await agentSay(
    "Hi, this is the project concierge for Parramatta Central. Press Talk once and tell me what you are looking for.",
  );
}

function stopVoiceDemo() {
  voiceActive = false;
  voiceListening = false;
  if (voiceRecognition) voiceRecognition.abort();
  if (window.speechSynthesis) window.speechSynthesis.cancel();
  els.startVoice.disabled = false;
  els.talkVoice.disabled = false;
  els.voiceStatus.textContent = "Audio stopped. Press Talk once when you want the agent to listen.";
}

async function testMicrophone() {
  try {
    await ensureMicrophoneAccess();
    els.voiceStatus.textContent = "Microphone access works. Press Talk once and speak after the Listening status appears.";
  } catch (error) {
    els.voiceStatus.textContent = error.message;
  }
}

async function ensureMicrophoneAccess() {
  if (!navigator.mediaDevices?.getUserMedia) {
    throw new Error("This browser does not expose microphone access. Try Chrome/Edge with the server URL.");
  }

  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((track) => track.stop());
  } catch (error) {
    if (error.name === "NotAllowedError") {
      throw new Error("Microphone permission is blocked. Allow mic access in the browser, then try again.");
    }
    if (error.name === "NotFoundError") {
      throw new Error("No microphone was found. Check your input device.");
    }
    throw new Error(`Microphone check failed: ${error.message || error.name}`);
  }
}

function listenForTurn() {
  if (!voiceActive) {
    els.voiceStatus.textContent = "Press Start voice agent first.";
    return;
  }
  if (voiceListening) return;

  const Recognition = getSpeechRecognition();
  voiceRecognition = new Recognition();
  voiceRecognition.lang = "en-AU";
  voiceRecognition.interimResults = false;
  voiceRecognition.maxAlternatives = 1;

  if (window.speechSynthesis) window.speechSynthesis.cancel();

  voiceRecognition.onaudiostart = () => {
    els.voiceStatus.textContent = "Microphone is open. Speak now.";
  };

  voiceRecognition.onspeechstart = () => {
    els.voiceStatus.textContent = "Speech detected. Keep going.";
  };

  voiceRecognition.onresult = async (event) => {
    const answer = event.results[0][0].transcript.trim();
    voiceListening = false;
    els.talkVoice.disabled = false;
    if (!answer) return;

    els.transcriptBox.textContent += `Lead: ${answer}\n`;
    captureLeadDetails(answer);

    const reply = await getAgentReply(answer);
    voiceLead = { ...voiceLead, ...removeEmptyPatch(reply.leadPatch || {}) };
    if (reply.done) {
      await agentSay(reply.text);
      await finishVoiceLead();
      return;
    }

    await agentSay(reply.text);
    els.voiceStatus.textContent = "Your turn. Press Talk once to reply.";
  };

  voiceRecognition.onerror = (event) => {
    if (!voiceActive) return;
    voiceListening = false;
    els.talkVoice.disabled = false;
    const messages = {
      "no-speech": "No speech was detected. Press Talk once, wait for 'Microphone is open', then speak close to the mic.",
      "audio-capture": "The browser could not capture microphone audio. Click Test microphone.",
      "not-allowed": "Microphone permission is blocked. Allow mic access in the browser and try again.",
      network:
        "Browser speech recognition had a network issue. This is why production should use Retell, Vapi, or OpenAI Realtime. Use typed fallback for this local test.",
    };
    els.voiceStatus.textContent = messages[event.error] || `Speech recognition error: ${event.error}`;
  };

  voiceRecognition.onend = () => {
    voiceListening = false;
    els.talkVoice.disabled = false;
  };

  els.voiceStatus.textContent = "Listening...";
  els.talkVoice.disabled = true;
  voiceListening = true;
  voiceRecognition.start();
}

async function handleTypedTurn(event) {
  event.preventDefault();
  if (!voiceActive) {
    els.voiceStatus.textContent = "Press Start voice agent first.";
    return;
  }

  const input = event.currentTarget.elements.message;
  const answer = input.value.trim();
  if (!answer) return;
  input.value = "";

  els.transcriptBox.textContent += `Lead: ${answer}\n`;
  captureLeadDetails(answer);
  const reply = await getAgentReply(answer);
  voiceLead = { ...voiceLead, ...removeEmptyPatch(reply.leadPatch || {}) };

  if (reply.done) {
    await agentSay(reply.text);
    await finishVoiceLead();
    return;
  }

  await agentSay(reply.text);
  els.voiceStatus.textContent = "Your turn. Use Talk once or typed fallback.";
}

async function agentSay(text) {
  els.voiceStatus.textContent = text;
  els.transcriptBox.textContent += `AI: ${text}\n`;
  voiceConversation.push({ role: "assistant", text });
  await speak(text);
}

function captureLeadDetails(text) {
  const normalized = text.toLowerCase();

  if (!voiceLead.name && /my name is|this is|i am|i'm/.test(normalized)) {
    voiceLead.name = text
      .replace(/^(my name is|this is|i am|i'm)\s+/i, "")
      .trim();
  }

  if (!voiceLead.interest && /(bed|bedroom|apartment|townhouse|house|land|villa|investment)/.test(normalized)) {
    voiceLead.interest = text;
  }

  if (!voiceLead.budget && /(\$|aud|nzd|k|million|budget|under|around|between)/.test(normalized)) {
    voiceLead.budget = text;
  }

  if (!voiceLead.timeline && /(now|month|months|year|soon|ready|looking|buy)/.test(normalized)) {
    voiceLead.timeline = text;
  }

  if (!voiceLead.finance && /(pre approved|pre-approved|broker|cash|loan|mortgage|finance)/.test(normalized)) {
    voiceLead.finance = text;
  }
}

async function getAgentReply(text) {
  voiceConversation.push({ role: "user", text });
  let response;
  try {
    response = await api("/api/ai-reply", {
      method: "POST",
      body: JSON.stringify({
        message: text,
        lead: voiceLead,
        conversation: voiceConversation.slice(-10),
      }),
    });
  } catch (error) {
    return {
      text: `I cannot reach the AI server. ${error.message}`,
      done: false,
      leadPatch: {},
    };
  }

  if (response.provider === "gemini") {
    els.voiceStatus.textContent = "Gemini AI responded.";
  }

  return {
    text: response.reply,
    done: response.done,
    leadPatch: response.leadPatch,
  };
}

function removeEmptyPatch(patch) {
  return Object.fromEntries(Object.entries(patch).filter(([, value]) => value));
}

async function finishVoiceLead() {
  voiceActive = false;
  els.voiceStatus.textContent = "Creating agent summary...";

  await api("/api/inbound-call", {
    method: "POST",
    body: JSON.stringify({
      ...voiceLead,
      name: voiceLead.name || "Browser Voice Lead",
      interest: voiceLead.interest || "General property enquiry",
      budget: voiceLead.budget || "Not captured",
      timeline: voiceLead.timeline || "Not captured",
      finance: voiceLead.finance || "Not captured",
      callOutcome: "answered",
    }),
  });

  await refresh();
  els.startVoice.disabled = false;
  els.talkVoice.disabled = false;
  els.voiceStatus.textContent = "Voice lead created and summarized for the agent.";
}
