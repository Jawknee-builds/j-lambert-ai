const http = require("node:http");
const fs = require("node:fs/promises");
const path = require("node:path");
const crypto = require("node:crypto");

const PORT = Number(process.env.PORT || 4173);
const HOST = process.env.HOST || "127.0.0.1";
const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash-lite";
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, "data");
const DB_PATH = path.join(DATA_DIR, "leads.json");

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".md": "text/markdown; charset=utf-8",
};

async function ensureDb() {
  await fs.mkdir(DATA_DIR, { recursive: true });
  try {
    await fs.access(DB_PATH);
  } catch {
    await fs.writeFile(DB_PATH, JSON.stringify(seedLeads(), null, 2));
  }
}

function seedLeads() {
  const now = new Date().toISOString();
  return [
    createLead({
      name: "Sarah Mitchell",
      phone: "+61 412 555 018",
      email: "sarah.mitchell@example.com",
      channel: "Meta form",
      project: "Parramatta Central",
      interest: "2-bed apartment near transport",
      budget: "AUD $750k-$850k",
      timeline: "0-3 months",
      finance: "Pre-approved",
      enquiryType: "form",
      callOutcome: "answered",
      createdAt: now,
    }),
    createLead({
      name: "Daniel Brooks",
      phone: "+64 21 555 204",
      email: "daniel.brooks@example.co.nz",
      channel: "Inbound call",
      project: "Auckland West Terraces",
      interest: "House-and-land package",
      budget: "NZD $900k-$1.05m",
      timeline: "6 months",
      finance: "Needs broker referral",
      enquiryType: "call",
      callOutcome: "answered",
      createdAt: now,
    }),
  ];
}

function createLead(input) {
  const lead = {
    id: input.id || crypto.randomUUID(),
    createdAt: input.createdAt || new Date().toISOString(),
    name: clean(input.name) || "Unknown lead",
    phone: clean(input.phone),
    email: clean(input.email),
    channel: clean(input.channel) || "Website form",
    project: clean(input.project) || "Project enquiry",
    interest: clean(input.interest) || "General property enquiry",
    budget: clean(input.budget) || "Not captured",
    timeline: clean(input.timeline) || "Not captured",
    finance: clean(input.finance) || "Not captured",
    enquiryType: input.enquiryType === "call" ? "call" : "form",
    callOutcome: input.callOutcome === "missed" ? "missed" : "answered",
    consent: Boolean(input.consent),
  };

  return enrichLead(lead);
}

function enrichLead(lead) {
  const score = scoreLead(lead);
  const status = score >= 80 ? "Hot" : score >= 50 ? "Warm" : "Cold";
  const callAction =
    lead.enquiryType === "call"
      ? "AI answered inbound call live"
      : lead.callOutcome === "answered"
        ? "AI called form lead within 60 seconds"
        : "AI call attempted; lead did not answer";

  const followUpStatus =
    lead.callOutcome === "missed"
      ? "Email/WhatsApp fallback sent"
      : "Brochure and inspection details sent after conversation";

  return {
    ...lead,
    score,
    status,
    ownerNextStep: nextStep(status, lead),
    summary: summarizeLead(status, lead),
    actions: [
      {
        type: "voice",
        status: lead.callOutcome === "missed" ? "missed" : "completed",
        detail: callAction,
        at: lead.createdAt,
      },
      {
        type: "follow-up",
        status: "sent",
        detail: followUpStatus,
        at: lead.createdAt,
      },
      {
        type: "agent-summary",
        status: "sent",
        detail: "Lead score, call notes, and next step sent to sales team",
        at: lead.createdAt,
      },
    ],
  };
}

function scoreLead(lead) {
  let score = 35;
  const timeline = lead.timeline.toLowerCase();
  const finance = lead.finance.toLowerCase();
  const budget = lead.budget.toLowerCase();

  if (timeline.includes("0-3") || timeline.includes("now") || timeline.includes("ready")) score += 28;
  if (timeline.includes("3") || timeline.includes("6")) score += 14;
  if (finance.includes("pre-approved") || finance.includes("approved")) score += 22;
  if (finance.includes("broker")) score += 8;
  if (budget.includes("$") || budget.includes("aud") || budget.includes("nzd")) score += 12;
  if (lead.callOutcome === "answered") score += 10;
  if (lead.enquiryType === "call") score += 6;

  return Math.min(score, 100);
}

function nextStep(status, lead) {
  if (status === "Hot") return `Agent should call ${lead.name} within 30 minutes and offer inspection slots.`;
  if (status === "Warm") return `Send extra project info and schedule a human callback within 24 hours.`;
  return "Keep in nurture sequence; ask for budget and buying timeline before agent time.";
}

function summarizeLead(status, lead) {
  const intro =
    lead.enquiryType === "call"
      ? `${lead.name} called about ${lead.project}.`
      : `${lead.name} submitted a ${lead.channel} enquiry for ${lead.project}.`;

  const outcome =
    lead.callOutcome === "missed"
      ? "The AI call was missed, so fallback follow-up was sent by email/WhatsApp."
      : "The AI handled the conversation and sent the approved property follow-up.";

  return `${intro} Interest: ${lead.interest}. Budget: ${lead.budget}. Timeline: ${lead.timeline}. Finance: ${lead.finance}. Intent: ${status}. ${outcome}`;
}

function clean(value) {
  return typeof value === "string" ? value.trim() : "";
}

async function readLeads() {
  await ensureDb();
  const raw = await fs.readFile(DB_PATH, "utf8");
  return JSON.parse(raw);
}

async function writeLeads(leads) {
  await fs.writeFile(DB_PATH, JSON.stringify(leads, null, 2));
}

async function readBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const raw = Buffer.concat(chunks).toString("utf8");
  return raw ? JSON.parse(raw) : {};
}

function sendJson(res, status, payload) {
  res.writeHead(status, { "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(payload));
}

async function serveStatic(req, res) {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const pathname = url.pathname === "/" ? "/index.html" : decodeURIComponent(url.pathname);
  const filePath = path.normalize(path.join(ROOT, pathname));

  if (!filePath.startsWith(ROOT)) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }

  try {
    const data = await fs.readFile(filePath);
    const ext = path.extname(filePath);
    res.writeHead(200, { "content-type": mimeTypes[ext] || "application/octet-stream" });
    res.end(data);
  } catch {
    res.writeHead(404);
    res.end("Not found");
  }
}

async function handleApi(req, res) {
  const url = new URL(req.url, `http://${req.headers.host}`);

  if (req.method === "GET" && url.pathname === "/api/leads") {
    const leads = await readLeads();
    sendJson(res, 200, leads.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
    return;
  }

  if (req.method === "GET" && url.pathname === "/api/metrics") {
    const leads = await readLeads();
    const metrics = {
      total: leads.length,
      hot: leads.filter((lead) => lead.status === "Hot").length,
      answered: leads.filter((lead) => lead.callOutcome === "answered").length,
      fallbackSent: leads.filter((lead) => lead.callOutcome === "missed").length,
    };
    sendJson(res, 200, metrics);
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/leads") {
    const body = await readBody(req);
    const lead = createLead({ ...body, enquiryType: "form" });
    const leads = await readLeads();
    leads.push(lead);
    await writeLeads(leads);
    sendJson(res, 201, lead);
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/inbound-call") {
    const body = await readBody(req);
    const lead = createLead({ ...body, enquiryType: "call", callOutcome: "answered", channel: "Inbound call" });
    const leads = await readLeads();
    leads.push(lead);
    await writeLeads(leads);
    sendJson(res, 201, lead);
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/ai-reply") {
    const body = await readBody(req);
    const reply = await createAiReply(body);
    sendJson(res, 200, reply);
    return;
  }

  sendJson(res, 404, { error: "Route not found" });
}

async function createAiReply(body) {
  if (!process.env.GEMINI_API_KEY) {
    return localAiReply(body);
  }

  try {
    return await geminiReply(body);
  } catch (error) {
    return {
      ...localAiReply(body),
      provider: "local-fallback",
      warning: `Gemini failed, used local fallback: ${error.message}`,
    };
  }
}

async function geminiReply(body) {
  const prompt = [
    "You are LeadPilot AI, a concise voice concierge for an AU/NZ real estate project.",
    "Your job: answer buyer questions, qualify the lead, and decide when to hand off to a human agent.",
    "Keep replies under 35 words because they will be spoken aloud.",
    "Ask only one question at a time.",
    "Do not invent exact legal, finance, or contract claims. Offer to send brochure or connect an agent.",
    "Return only valid JSON with this shape:",
    '{"reply":"spoken reply","done":false,"leadPatch":{"name":"","interest":"","budget":"","timeline":"","finance":""}}',
    "",
    `Project context: ${JSON.stringify(projectContext())}`,
    `Current lead fields: ${JSON.stringify(body.lead || {})}`,
    `Conversation: ${JSON.stringify(body.conversation || [])}`,
    `Latest buyer message: ${body.message || ""}`,
  ].join("\n");

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${process.env.GEMINI_API_KEY}`,
    {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: {
          responseMimeType: "application/json",
          temperature: 0.4,
          maxOutputTokens: 220,
        },
      }),
    },
  );

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(errorText.slice(0, 180));
  }

  const data = await response.json();
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text || "{}";
  const parsed = JSON.parse(text);

  return {
    provider: "gemini",
    reply: clean(parsed.reply) || "I can help with that. What budget range are you working with?",
    done: Boolean(parsed.done),
    leadPatch: sanitizeLeadPatch(parsed.leadPatch || {}),
  };
}

function projectContext() {
  return {
    project: "Parramatta Central",
    market: "AU/NZ real estate",
    priceGuide: "2-bed residences are guided around the high $700k to mid $800k range, subject to availability.",
    followUp: "Brochure, floorplans, and inspection options can be sent after the call.",
    handoff: "A licensed sales agent should handle exact availability, contract, deposit, finance, and legal details.",
  };
}

function localAiReply(body) {
  const message = clean(body.message);
  const lead = { ...(body.lead || {}) };
  const patch = inferLeadPatch(message, lead);
  const merged = { ...lead, ...patch };
  const normalized = message.toLowerCase();

  if (/(inspection|inspect|view|appointment|book|visit|saturday|sunday|tomorrow|done|thanks|thank you|bye)/.test(normalized)) {
    return {
      provider: "local",
      reply: hasMinimumLeadDetails(merged)
        ? "Perfect. I will send the brochure and mark this as a priority callback for the sales team."
        : "Happy to help. Before I pass this on, what budget and buying timeline should I note?",
      done: hasMinimumLeadDetails(merged),
      leadPatch: patch,
    };
  }

  if (/(price|cost|how much|range)/.test(normalized)) {
    return {
      provider: "local",
      reply:
        "Two bedroom residences are guided around the high seven hundreds to mid eight hundreds, subject to availability. What budget range are you working with?",
      done: false,
      leadPatch: patch,
    };
  }

  if (/(location|where|train|station|school|transport)/.test(normalized)) {
    return {
      provider: "local",
      reply:
        "The project is near transport, shops, and daily amenities. I can send the exact map in the brochure. Are you buying to live in or invest?",
      done: false,
      leadPatch: patch,
    };
  }

  if (/(brochure|floor plan|floorplan|send|email|whatsapp)/.test(normalized)) {
    return {
      provider: "local",
      reply: "Yes, I can send the brochure and floorplans. What type of property are you looking for?",
      done: false,
      leadPatch: patch,
    };
  }

  return {
    provider: "local",
    reply: nextMissingQuestion(merged),
    done: false,
    leadPatch: patch,
  };
}

function inferLeadPatch(message, lead) {
  const normalized = message.toLowerCase();
  const patch = {};

  if (!lead.name && /my name is|this is|i am|i'm/.test(normalized)) {
    patch.name = message.replace(/^(my name is|this is|i am|i'm)\s+/i, "").trim();
  }
  if (!lead.interest && /(bed|bedroom|apartment|townhouse|house|land|villa|investment)/.test(normalized)) {
    patch.interest = message;
  }
  if (!lead.budget && /(\$|aud|nzd|k|million|budget|under|around|between)/.test(normalized)) {
    patch.budget = message;
  }
  if (!lead.timeline && /(now|month|months|year|soon|ready|looking|buy)/.test(normalized)) {
    patch.timeline = message;
  }
  if (!lead.finance && /(pre approved|pre-approved|broker|cash|loan|mortgage|finance)/.test(normalized)) {
    patch.finance = message;
  }

  return sanitizeLeadPatch(patch);
}

function sanitizeLeadPatch(input) {
  return {
    name: clean(input.name),
    interest: clean(input.interest),
    budget: clean(input.budget),
    timeline: clean(input.timeline),
    finance: clean(input.finance),
  };
}

function hasMinimumLeadDetails(lead) {
  return Boolean(clean(lead.interest) && clean(lead.budget) && clean(lead.timeline));
}

function nextMissingQuestion(lead) {
  if (!clean(lead.name)) return "Got it. May I grab your name for the agent summary?";
  if (!clean(lead.interest)) return "What type of property are you looking for?";
  if (!clean(lead.budget)) return "What budget range are you working with?";
  if (!clean(lead.timeline)) return "When are you hoping to buy?";
  if (!clean(lead.finance)) return "Are you pre-approved, speaking with a broker, or still exploring finance?";
  return "That helps. Would you like the brochure sent, or should I mark this for an inspection callback?";
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.url.startsWith("/api/")) {
      await handleApi(req, res);
      return;
    }
    await serveStatic(req, res);
  } catch (error) {
    sendJson(res, 500, { error: error.message });
  }
});

ensureDb().then(() => {
  server.listen(PORT, HOST, () => {
    console.log(`LeadPilot AI MVP running at http://${HOST}:${PORT}`);
  });
});
